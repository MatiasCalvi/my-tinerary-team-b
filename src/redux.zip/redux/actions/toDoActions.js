import { createAction,createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { BASE_URL } from "../../api/url";

const getCities= createAsyncThunk ('getCities', async (value)=>{
    /* let url=`${BASE_URL}/${value}` */
    try {

        const res = await axios.get(`http://localhost:8000/api/${value}`)

        console.log(res.data.allcitties)
        return {value , cities : res.data.allcities}

      
    } catch (error) {
        console.log(error);
        return {
            payload: 'Error'
        }
    }
})


const toDoActions={

    getCities
}


export default toDoActions;