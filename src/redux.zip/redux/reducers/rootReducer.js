import toDoReducer from "./toDoReducer"

const rootReducer={
    cities : toDoReducer,
}

export default rootReducer;